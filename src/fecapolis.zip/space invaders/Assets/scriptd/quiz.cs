using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class QuizController : MonoBehaviour
{
    public StepByStepClimber[] capsulas; // Referência das cápsulas
    public TextMeshProUGUI perguntaTexto;
    public Button botaoA;
    public Button botaoB;
    public Button botaoC;
    public Button botaoD;

    private Questao[] questoes = new Questao[10];
    private int questaoAtual = 0;

    public TurnBasedSorter turnBasedSorter; // Referência para o TurnBasedSorter

    public void Start()
    {
        // Inicializar as questões
        questoes = new Questao[10]
        {
            new Questao { ID = 1, Pergunta = "Qual é 5 + 3?", A = "6", B = "7", C = "8", D = "9", Resposta = 3 },
            new Questao { ID = 2, Pergunta = "Qual é 10 - 4?", A = "5", B = "6", C = "7", D = "8", Resposta = 2 },
            new Questao { ID = 3, Pergunta = "Qual é 2 * 6?", A = "10", B = "11", C = "12", D = "13", Resposta = 3 },
            new Questao { ID = 4, Pergunta = "Qual é 15 / 3?", A = "4", B = "5", C = "6", D = "7", Resposta = 2 },
            new Questao { ID = 5, Pergunta = "Qual é 9 + 6?", A = "14", B = "15", C = "16", D = "17", Resposta = 1 },
            new Questao { ID = 6, Pergunta = "Qual é 7 - 2?", A = "3", B = "4", C = "5", D = "6", Resposta = 2 },
            new Questao { ID = 7, Pergunta = "Qual é 3 * 5?", A = "12", B = "13", C = "14", D = "15", Resposta = 4 },
            new Questao { ID = 8, Pergunta = "Qual é 12 / 4?", A = "3", B = "4", C = "5", D = "6", Resposta = 1 },
            new Questao { ID = 9, Pergunta = "Qual é 8 + 7?", A = "14", B = "15", C = "16", D = "17", Resposta = 2 },
            new Questao { ID = 10, Pergunta = "Qual é 6 * 6?", A = "35", B = "36", C = "37", D = "38", Resposta = 2 }
        };

        // Exibir a primeira questão
        ExibirQuestao();

        // Associe os botões aos métodos de verificação de resposta
        botaoA.onClick.AddListener(() => VerificarResposta(1));
        botaoB.onClick.AddListener(() => VerificarResposta(2));
        botaoC.onClick.AddListener(() => VerificarResposta(3));
        botaoD.onClick.AddListener(() => VerificarResposta(4));
    }

    void ExibirQuestao()
    {
        // Exibe a pergunta e as alternativas nos botões
        perguntaTexto.text = questoes[questaoAtual].Pergunta;
        botaoA.GetComponentInChildren<TextMeshProUGUI>().text = "A: " + questoes[questaoAtual].A;
        botaoB.GetComponentInChildren<TextMeshProUGUI>().text = "B: " + questoes[questaoAtual].B;
        botaoC.GetComponentInChildren<TextMeshProUGUI>().text = "C: " + questoes[questaoAtual].C;
        botaoD.GetComponentInChildren<TextMeshProUGUI>().text = "D: " + questoes[questaoAtual].D;
    }

    public void VerificarResposta(int respostaEscolhida)
{
    // Verifica se a resposta escolhida é a correta
    if (respostaEscolhida == questoes[questaoAtual].Resposta)
    {
        // Se a resposta estiver correta, anda um degrau
        if (turnBasedSorter != null)
        {
            turnBasedSorter.SubirDegrau();  // Chama o método que sobe um degrau
        }
        Debug.Log("Resposta correta! Cápsula subiu um degrau.");
    }
    else
    {
        Debug.Log("Resposta incorreta. Passando a vez...");

        // Chama a função de troca de vez como se a tecla J tivesse sido pressionada
        if (turnBasedSorter != null)
        {
            turnBasedSorter.TrocaVez();  // Passa para o próximo jogador
        }
    }

    // Avança para a próxima questão
    questaoAtual++;
    if (questaoAtual < questoes.Length)
    {
        ExibirQuestao(); // Exibe a próxima pergunta
    }
    else
    {
        Debug.Log("Fim do quiz!");
    }
}

    [System.Serializable]
    public class Questao
    {
        public int ID;
        public string Pergunta;
        public string A;
        public string B;
        public string C;
        public string D;
        public int Resposta; // Resposta correta (1 = A, 2 = B, 3 = C, 4 = D)
    }
}
